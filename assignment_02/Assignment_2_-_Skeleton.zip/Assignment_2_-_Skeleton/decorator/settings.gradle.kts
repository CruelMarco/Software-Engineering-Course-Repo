rootProject.name = "ChatApp"

