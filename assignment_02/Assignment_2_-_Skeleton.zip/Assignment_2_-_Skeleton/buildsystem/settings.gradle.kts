rootProject.name = "ChatApp"
